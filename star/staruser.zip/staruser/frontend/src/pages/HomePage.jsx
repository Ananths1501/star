"use client"

import { useState, useEffect, useContext } from "react"
import { useParams } from "react-router-dom"
import { AuthContext } from "../context/AuthContext"
import Carousel from "../components/Carousel"
import ProductCard from "../components/ProductCard"
import { productService } from "../services/api"

const HomePage = () => {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const { user } = useContext(AuthContext)
  const { userId } = useParams()

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await productService.getAllProducts()
        setProducts(response.data)

        // Extract unique categories (types)
        const uniqueTypes = [...new Set(response.data.map((product) => product.type))]
        setCategories(uniqueTypes)

        setLoading(false)
      } catch (err) {
        console.error("Error fetching products:", err)
        setError("Failed to load products. Please try again later.")
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  const carouselSlides = [
    {
      title: `Welcome back, ${user?.name || "User"}!`,
      description: "Explore our latest products and services",
      button: {
        text: "View Services",
        onClick: () => (window.location.href = `/${userId}/services`),
      },
    },
    {
      title: "Special Offers",
      description: "Check out our discounted products",
      button: {
        text: "Shop Now",
        onClick: () => document.getElementById("products-section")?.scrollIntoView({ behavior: "smooth" }),
      },
    },
    {
      title: "Need Help?",
      description: "Book a service with our professional electricians",
      button: {
        text: "Book Service",
        onClick: () => (window.location.href = `/${userId}/services`),
      },
    },
  ]

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  if (error) {
    return <div className="text-center text-pink-600 p-8">{error}</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Carousel slides={carouselSlides} />

      <div id="products-section" className="mt-12">
        <h2 className="text-2xl font-bold text-center text-purple-700 mb-8 relative after:content-[''] after:absolute after:bottom-[-10px] after:left-1/2 after:transform after:-translate-x-1/2 after:w-24 after:h-1 after:bg-gradient-to-r after:from-blue-600 after:via-purple-600 after:to-pink-600">
          Our Products
        </h2>

        {categories.map((category) => (
          <div className="mb-12" key={category}>
            <h3 className="text-xl font-semibold text-purple-700 mb-4 border-l-4 border-purple-500 pl-3">{category}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {products
                .filter((product) => product.type === category)
                .map((product) => (
                  <div key={product._id}>
                    <ProductCard product={product} />
                  </div>
                ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default HomePage
