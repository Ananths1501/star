import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { Toaster } from "react-hot-toast"
import AdminLogin from "./pages/admin/AdminLogin"
import AdminDashboard from "./pages/admin/AdminDashboard"
import AdminProducts from "./pages/admin/AdminProducts"
import AdminServices from "./pages/admin/AdminServices"
import AdminOrders from "./pages/admin/AdminOrders"
import AdminBill from "./pages/admin/AdminBill"
import AdminStocks from "./pages/admin/AdminStocks"
import AdminLayout from "./components/AdminLayout"
import { AuthProvider } from "./context/AuthContext"
import { ThemeProvider } from "./components/ThemeProvider"
import ProtectedRoute from "./components/ProtectedRoute"
import NotFoundPage from "./pages/NotFoundPage"

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="star-admin-theme">
      <AuthProvider>
        <Router>
          <Toaster position="top-right" />
          <Routes>
            <Route path="/admin/login" element={<AdminLogin />} />

            <Route
              path="/admin"
              element={
                <ProtectedRoute>
                  <AdminLayout />
                </ProtectedRoute>
              }
            >
              <Route path="dashboard" element={<AdminDashboard />} />
              <Route path="products" element={<AdminProducts />} />
              <Route path="services" element={<AdminServices />} />
              <Route path="orders" element={<AdminOrders />} />
              <Route path="bill" element={<AdminBill />} />
              <Route path="stocks" element={<AdminStocks />} />
            </Route>

            <Route path="/" element={<Navigate to="/admin/login" replace />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App
