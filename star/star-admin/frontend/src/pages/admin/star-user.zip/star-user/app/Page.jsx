const Page = () => {
    return (
      <div>
        <h1>Welcome to Star Electricals!</h1>
        <p>This is a placeholder page. Please replace this with your actual home page content.</p>
      </div>
    )
  }
  
  export default Page
  