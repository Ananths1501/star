const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

router.get('/category', productController.getProductsByCategory);
router.get('/filter', productController.getFilteredProducts);

module.exports = router;