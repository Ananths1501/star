// backend/seed.js
require("dotenv").config()
const mongoose = require("mongoose")
const connectDB = require("./config/db")
const Product = require("./models/Product")

// Sample product data
const products = [
  {
    name: 'LED Smart TV 55"',
    description: "4K Ultra HD Smart LED TV with HDR",
    price: 45999,
    category: "Television",
    brandName: "Samsung",
    images: ["https://via.placeholder.com/300x200?text=Samsung+TV"],
    stock: 15,
    rating: 4.5,
  },
  {
    name: "Refrigerator Double Door",
    description: "300L Double Door Frost Free Refrigerator",
    price: 32999,
    category: "Refrigerator",
    brandName: "LG",
    images: ["https://via.placeholder.com/300x200?text=LG+Refrigerator"],
    stock: 10,
    rating: 4.3,
  },
  {
    name: "Washing Machine Front Load",
    description: "8kg Front Load Washing Machine with Steam",
    price: 35999,
    category: "Washing Machine",
    brandName: "Bosch",
    images: ["https://via.placeholder.com/300x200?text=Bosch+Washing+Machine"],
    stock: 8,
    rating: 4.7,
  },
  {
    name: "Air Conditioner 1.5 Ton",
    description: "1.5 Ton Split AC with Inverter Technology",
    price: 38999,
    category: "Air Conditioner",
    brandName: "Daikin",
    images: ["https://via.placeholder.com/300x200?text=Daikin+AC"],
    stock: 12,
    rating: 4.4,
  },
  {
    name: "Microwave Oven",
    description: "28L Convection Microwave Oven",
    price: 12999,
    category: "Microwave",
    brandName: "IFB",
    images: ["https://via.placeholder.com/300x200?text=IFB+Microwave"],
    stock: 20,
    rating: 4.2,
  },
  {
    name: "Water Purifier",
    description: "RO+UV+UF Water Purifier with TDS Controller",
    price: 15999,
    category: "Water Purifier",
    brandName: "Kent",
    images: ["https://via.placeholder.com/300x200?text=Kent+Water+Purifier"],
    stock: 18,
    rating: 4.6,
  },
  {
    name: "Mixer Grinder",
    description: "750W Mixer Grinder with 3 Jars",
    price: 3999,
    category: "Small Appliances",
    brandName: "Philips",
    images: ["https://via.placeholder.com/300x200?text=Philips+Mixer"],
    stock: 25,
    rating: 4.1,
  },
  {
    name: "Induction Cooktop",
    description: "2000W Induction Cooktop with Auto Shut-off",
    price: 2999,
    category: "Small Appliances",
    brandName: "Prestige",
    images: ["https://via.placeholder.com/300x200?text=Prestige+Induction"],
    stock: 30,
    rating: 4.0,
  },
  {
    name: "LED Bulb Pack",
    description: "9W LED Bulbs (Pack of 4)",
    price: 599,
    category: "Lighting",
    brandName: "Philips",
    images: ["https://via.placeholder.com/300x200?text=Philips+LED+Bulbs"],
    stock: 50,
    rating: 4.3,
  },
  {
    name: "Ceiling Fan",
    description: "1200mm High Speed Ceiling Fan",
    price: 1999,
    category: "Fans",
    brandName: "Havells",
    images: ["https://via.placeholder.com/300x200?text=Havells+Fan"],
    stock: 22,
    rating: 4.2,
  },
  {
    name: "Electric Kettle",
    description: "1.5L Electric Kettle with Auto Shut-off",
    price: 1299,
    category: "Small Appliances",
    brandName: "Morphy Richards",
    images: ["https://via.placeholder.com/300x200?text=Morphy+Richards+Kettle"],
    stock: 35,
    rating: 4.0,
  },
  {
    name: "Room Heater",
    description: "2000W Oil Filled Room Heater",
    price: 7999,
    category: "Seasonal",
    brandName: "Bajaj",
    images: ["https://via.placeholder.com/300x200?text=Bajaj+Heater"],
    stock: 15,
    rating: 4.1,
  },
]

const seedProducts = async () => {
  try {
    // Connect to database
    await connectDB()

    // Delete existing products
    await Product.deleteMany({})
    console.log("Deleted existing products")

    // Insert new products
    await Product.insertMany(products)
    console.log("Added sample products to database")

    // Disconnect from database
    mongoose.connection.close()
  } catch (error) {
    console.error("Error seeding database:", error)
    process.exit(1)
  }
}

// Run the seed function
seedProducts()
