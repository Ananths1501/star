const Product = require('../models/Product');

exports.getProductsByCategory = async (req, res) => {
  try {
    const products = await Product.aggregate([
      { $group: { _id: "$category", products: { $push: "$$ROOT" } } }
    ]);
    
    const result = {};
    products.forEach(cat => {
      result[cat._id] = cat.products;
    });
    
    res.json(result);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch products', error: error.message });
  }
};

exports.getFilteredProducts = async (req, res) => {
  try {
    const { category, brand, price } = req.query;
    const filter = {};
    
    if (category) filter.category = category;
    if (brand) filter.brandName = brand;
    
    if (price) {
      const [min, max] = price.split('-').map(Number);
      filter.price = { $gte: min };
      if (max) filter.price.$lte = max;
    }
    
    const products = await Product.find(filter);
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'Failed to filter products', error: error.message });
  }
};