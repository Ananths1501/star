const ProductCard = ({ product, user, onAddToCart }) => {
    return (
      <div className="border rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
        <img 
          src={product.images[0] || '/placeholder-product.jpg'} 
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        <div className="p-4">
          <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
          <p className="text-gray-600 text-sm mb-2">{product.brandName}</p>
          <p className="font-bold text-blue-600 mb-3">₹{product.price.toLocaleString()}</p>
          
          {user ? (
            <div className="flex space-x-2">
              <button
                onClick={() => onAddToCart(product)}
                className="flex-1 bg-blue-600 text-white py-1 rounded hover:bg-blue-700"
              >
                Add to Cart
              </button>
              <button className="flex-1 bg-green-600 text-white py-1 rounded hover:bg-green-700">
                Buy Now
              </button>
            </div>
          ) : (
            <button className="w-full bg-gray-600 text-white py-1 rounded hover:bg-gray-700">
              Login to Order
            </button>
          )}
        </div>
      </div>
    );
  };
  
  export default ProductCard;